# Miras Abilbai: personal portfolio
Plain HTML, CSS and JavaScript. No build step.

## Run locally
Open `index.html`, or run `python3 -m http.server` and visit http://localhost:8000.

## Files to replace
- `images/profile.jpg`: portrait (taken from the CV).
- `documents/resume.pdf`: CV used by Download CV.
- `videos/avatar.mp4`: HeyGen avatar video. Until it exists, a placeholder shows on About.
- Social links: in `contact.html`, replace `href="#"` on the Instagram, LinkedIn, Telegram buttons.

## Add a project permanently
In `portfolio.html`, copy an `<article class="card">` block inside the section you want. The on-page form only saves to your own browser.

## Contact form
Demo only: validates input, sends nothing. Connect Formspree or similar later.

## Publish
1. `git init && git add . && git commit -m "Portfolio"`, push to a new GitHub repo.
2. On vercel.com choose Add New, Project, import the repo, Framework: Other, Deploy.
