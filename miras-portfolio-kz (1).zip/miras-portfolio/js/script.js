// Theme (saved in localStorage)
const root=document.documentElement;
try{root.dataset.theme=localStorage.getItem('theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light')}catch(e){}
document.getElementById('theme').onclick=()=>{const t=root.dataset.theme==='dark'?'light':'dark';root.dataset.theme=t;try{localStorage.setItem('theme',t)}catch(e){}};
// Mobile menu
const links=document.querySelector('.links');document.getElementById('menu').onclick=e=>{const o=links.classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',o)};
// Active nav link
const cur=location.pathname.split('/').pop()||'index.html';
document.querySelectorAll('.links a.l').forEach(a=>a.classList.toggle('active',a.getAttribute('href')===cur));
// Reveal on scroll
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.rv').forEach(el=>io.observe(el));
// Toast
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3500)}
// Video: show player only if the file really exists
const v=document.querySelector('.vbox video');
if(v){v.addEventListener('loadedmetadata',()=>v.parentElement.classList.add('ok'));v.load()}
// Contact form validation (demo, no backend)
const f=document.getElementById('cform');
if(f){f.addEventListener('submit',e=>{e.preventDefault();let ok=true;
 const rules={name:v=>v.trim().length>=2||'Атыңызды енгізіңіз (кемінде 2 таңба).',email:v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)||'Дұрыс электрондық пошта мекенжайын енгізіңіз.',message:v=>v.trim().length>=10||'Хабарлама кемінде 10 таңбадан тұруы керек.'};
 for(const k in rules){const el=f.elements[k],r=rules[k](el.value);el.classList.toggle('bad',r!==true);el.nextElementSibling.textContent=r===true?'':r;if(r!==true)ok=false}
 if(ok){toast('Хабарлама дайын. Бұл демо-форма әзірге серверге қосылмаған, сондықтан Мирасқа «Хат жазу» батырмасы арқылы жазыңыз.');f.reset()}})}
// Portfolio: add / remove projects (saved in this browser)
const pl=document.getElementById('plist');
if(pl){const K='projects',get=()=>{try{return JSON.parse(localStorage.getItem(K))||[]}catch(e){return[]}};
 const draw=()=>{pl.innerHTML='';const d=get();if(!d.length)pl.innerHTML='<div class=\"empty\">Жеке жобалар әлі қосылмаған. Біріншісін қосу үшін төмендегі форманы пайдаланыңыз.</div>';
  d.forEach((p,i)=>{const c=document.createElement('article');c.className='card';c.innerHTML='<span class=meta></span><h3></h3><p></p><button class=\"btn s\" style=\"margin-top:14px\">Жою</button>';
   c.children[0].textContent=p.type;c.children[1].textContent=p.title;c.children[2].textContent=p.desc;
   c.querySelector('button').onclick=()=>{const a=get();a.splice(i,1);localStorage.setItem(K,JSON.stringify(a));draw()};pl.append(c)})};
 draw();document.getElementById('pform').onsubmit=e=>{e.preventDefault();const g=n=>e.target.elements[n].value.trim();
  if(!g('title')||!g('desc')){toast('Атауы мен сипаттамасын енгізіңіз.');return}
  try{localStorage.setItem(K,JSON.stringify([...get(),{type:g('type'),title:g('title'),desc:g('desc')}]));}catch(x){toast('Бұл браузерде сақтау қолжетімсіз.');return}
  e.target.reset();draw();toast('Жоба қосылды.')}}
document.querySelectorAll("[data-todo]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();toast("Сілтемеңізді contact.html файлына қосыңыз")}))
